import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class Cv extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		PrintWriter out=response.getWriter();
		response.setContentType("application/vnd.ms-docs");
		String name=request.getParameter("NAME");
		String email=request.getParameter("EMAIL");
		String phone=request.getParameter("PHONE");
		String career=request.getParameter("CAREER");
		String course=request.getParameter("COURSE");
		String branch=request.getParameter("BRANCH");
		String ins1=request.getParameter("INS1");
		String un1=request.getParameter("UN1");
		String year1=request.getParameter("YEAR1");
		String gpa1=request.getParameter("GPA1");
		String ins2=request.getParameter("INS2");
		String un2=request.getParameter("UN2");
		String year2=request.getParameter("YEAR2");
		String gpa2=request.getParameter("GPA2");
		String ins3=request.getParameter("INS3");
		String un3=request.getParameter("UN3");
		String year3=request.getParameter("YEAR3");
		String gpa3=request.getParameter("GPA3");
		String skills=request.getParameter("SKILLS");
		String tools=request.getParameter("TOOLS");
		//if(request.getParameter("C1")!=NULL)
		String c1=request.getParameter("C1");
	//if(request.getParameter("C2")!=NULL)
		String c2=request.getParameter("C2");
	 //if(request.getParameter("C3")!=NULL)
		String c3=request.getParameter("C3");
//	if(request.getParameter("C4")!=NULL)
		String c4=request.getParameter("C4");
	//if(request.getParameter("INT1")!=NULL)
		String int1=request.getParameter("INT1");
	//if(request.getParameter("INT2")!=NULL)
		String int2=request.getParameter("INT2");
	//if(request.getParameter("PN1")!=NULL)
		String pn1=request.getParameter("PN1");
	//if(request.getParameter("DES1")!=NULL)
		String des1=request.getParameter("DES1");
	//if(request.getParameter("TECH1")!=NULL)
		String tech1=request.getParameter("TECH1");
	//	if(request.getParameter("PN1")!=NULL)
		String pn2=request.getParameter("PN2");
	//if(request.getParameter("DES1")!=NULL)
		String des2=request.getParameter("DES2");
	//if(request.getParameter("TECH1")!=NULL)
		String tech2=request.getParameter("TECH2");
		String industry=request.getParameter("INDUSTRY");
		String participate=request.getParameter("PARTICPATE");
		String strength=request.getParameter("STRENGTH");
		String father=request.getParameter("FATHER");
		String mother=request.getParameter("MOTHER");
		String hobbies=request.getParameter("HOBBIES");
		String language=request.getParameter("LANGUAGE");
		String declaration=request.getParameter("DECLARE");
		out.print("<html><body>");
		out.print("<table align=center><tr><td>Name</td><td>"+name+"</td></tr><tr><td>Email</td><td>"+email+"</td></tr>");
		out.print("<tr><td>Phone</td><td>"+phone+"</td></tr>");
out.print("<tr><td>Career Objective</td><td>"+career+"</td></tr><tr><td><h2>EDUCATION DETAILS</h2></td><td></td></tr>");
out.print("<tr><td><h3>GRADUATION DETAILS</h3></td><td></td></tr>");
	//out.print("<tr><td>Course</td><td>"+course+"</td></tr>");
	//out.print("<tr><td>Branch</td><td>"+branch+"</td></tr>");
out.print("<tr><table border=1><th>Course</th><th>Institute</th><th>University/Board</th><th>Year Of Passing</th><th>%/CGPA</th></tr>");
out.print("<tr><td>"+course+"("+branch+")</td><td>"+ins1+"</td>");
out.print("<td>"+un1+"</td>");
out.print("<td>"+year1+"</td></tr>");
out.print("<tr><td>Intermediate</td><td>"+ins2+"</td>");
out.print("<td>"+un2+"</td>");
out.print("<td>"+year2+"</td></tr>");
out.print("<tr><td>School</td><td>"+ins3+"</td>");
out.print("<td>"+un3+"</td>");
out.print("<td>"+year3+"</td></tr>");
out.print("</table>");
out.print("<tr><td>Technical Skills</td><td>"+skills+"</td></tr><tr><td>Tools Used</td><td>"+tools+"</td></tr></table></td></tr>");
out.print("<tr><td>Training and Certification</td><td>");
out.print(c1+"<br>"+c2+"<br>"+c3+"<br>"+c4+"<td>");
out.print("<tr><td>Internship</td><td>"+int1+"<br>"+int2+"</td></tr>");
out.print("<tr><td><h3><label>Projects</label></h3></td>");
out.print("<tr><td><label>1.Project Name</label></td><td>"+pn1+"</td></tr>");
out.print("<tr><td><label>Description</label></td><td>"+des1+"</td></tr><br>");
out.print("<tr><td>Technologies Used</td><td>"+tech1+"</td></tr><br>");

out.print("<tr><td><label>2.Project Name</label></td><td>"+pn2+"</td></tr>");
out.print("<tr><td><label>Description</label></td><td>"+des2+"</td></tr><br>");
out.print("<tr><td>Technologies Used</td><td>"+tech2+"</td></tr><br>");
out.print("<tr><td>Industrial Exposure</td><td>"+industry+"</td></tr><br>");
out.print("<tr><td>Participations</td><td>"+participate+"</td></tr><br>");
out.print("<tr><td>Strengths</td><td>"+strength+"</td></tr><br>");
out.print("<tr><td><h3>PERSONAL DETAILS</h3></td><td></td></tr>");
out.print("<tr><td>Father's name</td><td>"+father+"</td></tr>");
out.print("<tr><td>Mother's name</td><td>"+mother+"</td></tr>");
out.print("<tr><td>Hobbies</td><td>"+hobbies+"</td></tr>");
out.print("<tr><td>Languages Known</td><td>"+language+"</td></tr></table>");
out.print(declaration);
out.print("<h3 align=right>"+name+"</h3>");

		out.print("</body></html>");
		out.close();
	}
}
	